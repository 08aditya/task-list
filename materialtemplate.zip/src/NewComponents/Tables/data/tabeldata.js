// Material Dashboard 2 React components
import Apidata from "./data";
import { useState } from "react";

export default function authorsTableData() {
  console.log(Apidata);
  return {
    columns: [
      { Header: "Name", accessor: "Name", width: "45%", align: "left" },
      { Header: "Phone", accessor: "Phone", align: "left" },
      { Header: "Occupation", accessor: "Occupation", align: "center" },
      { Header: "Comments", accessor: "Comments", width: "20%", align: "center" },
    ],

    rows: Apidata.map((item) => ({
      Name: item.name,
      Phone: item.phone,
      Occupation: item.Occupation,
      Comments: item.comments,
    })),
  };
}
